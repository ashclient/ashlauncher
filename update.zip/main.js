// main.js
const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const os = require("os");
const fs = require("fs");
const fsp = fs.promises;
const { spawn } = require("child_process");
const http = require("http");
const https = require("https");
const { URL } = require("url");
const { PublicClientApplication } = require("@azure/msal-node");
const extract = require("extract-zip");
const settingsStore = require("./settings");
const AdmZip = require("adm-zip");

const REPO_OWNER = "ashclient";
const REPO_NAME = "ashlauncher";

const VERSION_URL = `https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/version.json`;
const UPDATE_ZIP_URL = `https://raw.githubusercontent.com/${REPO_OWNER}/${REPO_NAME}/main/update.zip`;

// ============================================================
// MSAL + Minecraft config
// ============================================================
const MS_CLIENT_ID = "0c76d921-5349-4799-92ea-9d9cf1808a4e";
const MS_REDIRECT_URI = "http://localhost:19191/auth/callback";
const MS_SCOPES = ["XboxLive.signin", "offline_access"];

const MSAL_CACHE_PATH = path.join(
  os.homedir(),
  "AppData",
  "Roaming",
  "ashclient",
  "msal_cache.json"
);

const msalConfig = {
  auth: {
    clientId: MS_CLIENT_ID,
    authority: "https://login.microsoftonline.com/consumers"
  },
  system: {
    loggerOptions: {
      loggerCallback(level, message) {
        console.log(message);
      },
      piiLoggingEnabled: false,
      logLevel: 2
    }
  },
  cache: {
    cachePlugin: {
      beforeCacheAccess: async (ctx) => {
        try {
          const data = await fsp.readFile(MSAL_CACHE_PATH, "utf8").catch(() => "");
          if (data) ctx.tokenCache.deserialize(data);
        } catch {}
      },
      afterCacheAccess: async (ctx) => {
        if (ctx.cacheHasChanged) {
          try {
            await fsp.mkdir(path.dirname(MSAL_CACHE_PATH), { recursive: true });
            await fsp.writeFile(MSAL_CACHE_PATH, ctx.tokenCache.serialize(), "utf8");
          } catch {}
        }
      }
    }
  }
};

const pca = new PublicClientApplication(msalConfig);

// ============================================================
// CDN + Libraries
// ============================================================
const ASH_CDN_BASE_URL = "https://raw.githubusercontent.com/ashclient/AshClient-CDN/main/";
const LIBRARIES_BASE_URL = "https://libraries.minecraft.net/";

const LIBRARY_PATHS = [
  "com/mojang/netty/1.8.8/netty-1.8.8.jar",
  "oshi-project/oshi-core/1.1/oshi-core-1.1.jar",
  "net/java/dev/jna/jna/3.4.0/jna-3.4.0.jar",
  "net/java/dev/jna/platform/3.4.0/platform-3.4.0.jar",
  "com/ibm/icu/icu4j-core-mojang/51.2/icu4j-core-mojang-51.2.jar",
  "net/sf/jopt-simple/jopt-simple/4.6/jopt-simple-4.6.jar",
  "com/paulscode/codecjorbis/20101023/codecjorbis-20101023.jar",
  "com/paulscode/codecwav/20101023/codecwav-20101023.jar",
  "com/paulscode/libraryjavasound/20101123/libraryjavasound-20101123.jar",
  "com/paulscode/librarylwjglopenal/20100824/librarylwjglopenal-20100824.jar",
  "com/paulscode/soundsystem/20120107/soundsystem-20120107.jar",
  "io/netty/netty-all/4.0.23.Final/netty-all-4.0.23.Final.jar",
  "com/google/guava/guava/17.0/guava-17.0.jar",
  "org/apache/commons/commons-lang3/3.3.2/commons-lang3-3.3.2.jar",
  "commons-io/commons-io/2.4/commons-io-2.4.jar",
  "commons-codec/commons-codec/1.9/commons-codec-1.9.jar",
  "net/java/jinput/jinput/2.0.5/jinput-2.0.5.jar",
  "net/java/jutils/jutils/1.0.0/jutils-1.0.0.jar",
  "com/google/code/gson/gson/2.2.4/gson-2.2.4.jar",
  "com/mojang/authlib/1.5.21/authlib-1.5.21.jar",
  "com/mojang/realms/1.7.59/realms-1.7.59.jar",
  "org/apache/commons/commons-compress/1.8.1/commons-compress-1.8.1.jar",
  "org/apache/httpcomponents/httpclient/4.3.3/httpclient-4.3.3.jar",
  "commons-logging/commons-logging/1.1.3/commons-logging-1.1.3.jar",
  "org/apache/httpcomponents/httpcore/4.3.2/httpcore-4.3.2.jar",
  "org/apache/logging/log4j/log4j-api/2.0-beta9/log4j-api-2.0-beta9.jar",
  "org/apache/logging/log4j/log4j-core/2.0-beta9/log4j-core-2.0-beta9.jar",
  "org/lwjgl/lwjgl/lwjgl/2.9.4-nightly-20150209/lwjgl-2.9.4-nightly-20150209.jar",
  "org/lwjgl/lwjgl/lwjgl_util/2.9.4-nightly-20150209/lwjgl_util-2.9.4-nightly-20150209.jar",
  "org/lwjgl/lwjgl/lwjgl-platform/2.9.4-nightly-20150209/lwjgl-platform-2.9.4-nightly-20150209.jar",
  "org/lwjgl/lwjgl/lwjgl/2.9.2-nightly-20140822/lwjgl-2.9.2-nightly-20140822.jar",
  "org/lwjgl/lwjgl/lwjgl_util/2.9.2-nightly-20140822/lwjgl_util-2.9.2-nightly-20140822.jar",
  "tv/twitch/twitch/6.5/twitch-6.5.jar"
];

const NATIVE_JARS = [
  "org/lwjgl/lwjgl/lwjgl-platform/2.9.4-nightly-20150209/lwjgl-platform-2.9.4-nightly-20150209-natives-windows.jar",
  "org/lwjgl/lwjgl/lwjgl-platform/2.9.2-nightly-20140822/lwjgl-platform-2.9.2-nightly-20140822-natives-windows.jar",
  "net/java/jinput/jinput-platform/2.0.5/jinput-platform-2.0.5-natives-windows.jar",
  "tv/twitch/twitch-platform/6.5/twitch-platform-6.5-natives-windows-64.jar",
  "tv/twitch/twitch-external-platform/4.5/twitch-external-platform-4.5-natives-windows-64.jar"
];

// ============================================================
// Ash custom resources
// ============================================================
const CUSTOM_CLIENTINPUT_REL = "resources/ClientInput.dll";
const CUSTOM_DISCORD_JAR_REL = "resources/java-discord-rpc-2.0.1-all.jar";

const CLIENTINPUT_URL = ASH_CDN_BASE_URL + CUSTOM_CLIENTINPUT_REL;
const DISCORD_RPC_JAR_URL = ASH_CDN_BASE_URL + CUSTOM_DISCORD_JAR_REL;

const ASHCLIENT_STORAGE = path.join(os.homedir(), "AppData", "Roaming", "ashclient");
const DISCORD_RPC_LOCAL_JAR = path.join(ASHCLIENT_STORAGE, "java-discord-rpc-2.0.1-all.jar");

// ============================================================
// Helper functions
// ============================================================
function cleanRel(p) {
  return p.replace(/\\/g, "/").replace(/(\.\.[/\\])+/g, "").replace(/^\/+/, "");
}

async function downloadFile(url, dest, id = "unknown") {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);

    https.get(url, (res) => {
      if (res.statusCode !== 200) {
        file.close(() => fs.unlink(dest, () => {}));
        return reject(new Error(`Failed to download ${url}: HTTP ${res.statusCode}`));
      }

      const total = parseInt(res.headers["content-length"] || "0");
      let downloaded = 0;

      res.on("data", (chunk) => {
        downloaded += chunk.length;

        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send("ash:downloadProgress", {
            id,
            downloaded,
            total,
            percent: total ? Math.floor((downloaded / total) * 100) : 0
          });
        }
      });

      res.pipe(file);

      file.on("finish", () => {
        file.close(() => {
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send("ash:downloadProgress", {
              id,
              downloaded: total || downloaded,
              total: total || downloaded,
              percent: 100
            });
          }
          resolve();
        });
      });
    }).on("error", (err) => {
      file.close(() => fs.unlink(dest, () => {}));
      reject(err);
    });
  });
}

async function downloadWithFallback(rel, dest) {
  const safe = cleanRel(rel);
  const mojang = LIBRARIES_BASE_URL + safe;
  const cdn = ASH_CDN_BASE_URL + safe;

  try {
    await downloadFile(mojang, dest, `lib:${safe}`);
  } catch {
    await downloadFile(cdn, dest, `lib:${safe}`);
  }
}

async function fileExists(p) {
  try {
    await fsp.access(p);
    return true;
  } catch {
    return false;
  }
}

function fetchRemoteVersion() {
  return new Promise((resolve, reject) => {
    https.get(VERSION_URL, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data).version);
        } catch (e) {
          reject(e);
        }
      });
    }).on("error", reject);
  });
}

function downloadAndApplyUpdate() {
  return new Promise((resolve, reject) => {
    const dest = path.join(process.cwd(), "update.zip");
    const stream = fs.createWriteStream(dest);

    https.get(UPDATE_ZIP_URL, (response) => {
      response.pipe(stream);
      stream.on("finish", () => {
        stream.close(() => {
          try {
            const zip = new AdmZip(dest);
            zip.extractAllTo(process.cwd(), true);
            fs.unlinkSync(dest);
            resolve(true);
          } catch (e) {
            reject(e);
          }
        });
      });
    }).on("error", reject);
  });
}

// ============================================================
// Ensure AshClient 1.8.9 files
// ============================================================
async function ensureAshClientVersion(mcDir) {
  const versionRoot = path.join(mcDir, "versions", "ashclient-1.8.9");
  const jarPath = path.join(versionRoot, "ashclient-1.8.9.jar");
  const jsonPath = path.join(versionRoot, "ashclient-1.8.9.json");

  const JAR_URL = ASH_CDN_BASE_URL + "releases/ashclient-1.8.9.jar";
  const JSON_URL = ASH_CDN_BASE_URL + "releases/ashclient-1.8.9.json";

  await fsp.mkdir(versionRoot, { recursive: true });

  let needJar = !(await fileExists(jarPath));
  if (!needJar && fs.statSync(jarPath).size < 15000) needJar = true;

  if (needJar) await downloadFile(JAR_URL, jarPath, "ashclient-jar");

  let needJson = !(await fileExists(jsonPath));
  if (!needJson && fs.statSync(jsonPath).size < 10) needJson = true;

  if (needJson) await downloadFile(JSON_URL, jsonPath, "ashclient-json");

  return { jarPath, jsonPath };
}

// ============================================================
// Library + Native extraction
// ============================================================
async function ensureLibraries(librariesDir) {
  await fsp.mkdir(librariesDir, { recursive: true });

  for (const rel of LIBRARY_PATHS) {
    const full = path.join(librariesDir, cleanRel(rel));
    if (await fileExists(full)) continue;

    await fsp.mkdir(path.dirname(full), { recursive: true });
    await downloadWithFallback(rel, full);
  }
}

async function extractNatives(librariesDir, nativesDir) {
  await fsp.mkdir(nativesDir, { recursive: true });

  for (const rel of NATIVE_JARS) {
    const jar = path.join(librariesDir, cleanRel(rel));
    if (!(await fileExists(jar))) {
      await fsp.mkdir(path.dirname(jar), { recursive: true });
      await downloadWithFallback(rel, jar);
    }

    await extract(jar, { dir: nativesDir }).catch(() =>
      console.error("[Natives] Failed:", jar)
    );
  }
}

// ============================================================
// Full Microsoft → Minecraft login chain
// ============================================================
async function httpsRequestJson(url, options, bodyObj) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);

    const req = https.request(
      {
        method: options.method || "GET",
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        headers: options.headers || {}
      },
      (res) => {
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => {
          if (res.statusCode < 200 || res.statusCode >= 300)
            return reject(new Error(`HTTP ${res.statusCode}: ${data}`));
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(e);
          }
        });
      }
    );

    req.on("error", reject);
    if (bodyObj) req.write(JSON.stringify(bodyObj));
    req.end();
  });
}

async function loginMinecraftWithMsAccessToken(msAccessToken) {
  const xblResp = await httpsRequestJson(
    "https://user.auth.xboxlive.com/user/authenticate",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-xbl-contract-version": "1"
      }
    },
    {
      Properties: {
        AuthMethod: "RPS",
        SiteName: "user.auth.xboxlive.com",
        RpsTicket: "d=" + msAccessToken
      },
      RelyingParty: "http://auth.xboxlive.com",
      TokenType: "JWT"
    }
  );

  const xbl = xblResp.Token;
  const uhs = xblResp.DisplayClaims.xui[0].uhs;

  const xstsResp = await httpsRequestJson(
    "https://xsts.auth.xboxlive.com/xsts/authorize",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "x-xbl-contract-version": "1"
      }
    },
    {
      Properties: {
        SandboxId: "RETAIL",
        UserTokens: [xbl]
      },
      RelyingParty: "rp://api.minecraftservices.com/",
      TokenType: "JWT"
    }
  );

  const identity = `XBL3.0 x=${uhs};${xstsResp.Token}`;

  const login = await httpsRequestJson(
    "https://api.minecraftservices.com/authentication/login_with_xbox",
    {
      method: "POST",
      headers: { "Content-Type": "application/json" }
    },
    { identityToken: identity }
  );

  let profile = null;
  try {
    profile = await httpsRequestJson(
      "https://api.minecraftservices.com/minecraft/profile",
      {
        method: "GET",
        headers: { Authorization: `Bearer ${login.access_token}` }
      }
    );
  } catch {}

  return { mcAccessToken: login.access_token, mcProfile: profile };
}

// Silent login at startup
async function trySilentMicrosoftLoginAndMinecraft() {
  try {
    const accounts = await pca.getTokenCache().getAllAccounts();
    if (!accounts?.length) return null;

    const acc = accounts[0];
    const token = await pca.acquireTokenSilent({
      account: acc,
      scopes: MS_SCOPES
    });

    const mc = await loginMinecraftWithMsAccessToken(token.accessToken);

    msAccount = {
      username: mc?.mcProfile?.name || acc.name || acc.username,
      microsoftName: acc.username,
      minecraftName: mc?.mcProfile?.name || null,
      minecraftUuid: mc?.mcProfile?.id || null,
      minecraftAccessToken: mc?.mcAccessToken || null
    };

    console.log("[Auth] Silent login success:", msAccount.username);
    return msAccount;
  } catch (e) {
    console.error("[Auth] Silent login failed:", e);
    return null;
  }
}

// ============================================================
// Window
// ============================================================
let mainWindow = null;

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1100,
    height: 650,
    minWidth: 900,
    minHeight: 550,
    backgroundColor: "#050510",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile("index.html");
}

// ============================================================
// Microsoft login UI
// ============================================================
let msAccount = null;

function performInteractiveMicrosoftLogin() {
  return new Promise(async (resolve, reject) => {
    let server;
    let popup;
    let finished = false;

    function done() {
      if (finished) return;
      finished = true;
      try { server.close(); } catch {}
      if (popup && !popup.isDestroyed()) popup.close();
    }

    try {
      server = http.createServer(async (req, res) => {
        const url = new URL(req.url, MS_REDIRECT_URI);
        if (url.pathname !== "/auth/callback") {
          res.writeHead(404); res.end(); return;
        }

        const code = url.searchParams.get("code");
        if (!code) {
          res.writeHead(400); res.end("Missing code");
          done(); return reject(new Error("Missing code"));
        }

        res.writeHead(200); res.end("Login OK!");

        const tokenResp = await pca.acquireTokenByCode({
          code,
          scopes: MS_SCOPES,
          redirectUri: MS_REDIRECT_URI
        });

        const mc = await loginMinecraftWithMsAccessToken(tokenResp.accessToken);

        msAccount = {
          username: mc?.mcProfile?.name || tokenResp.account.name,
          microsoftName: tokenResp.account.username,
          minecraftName: mc?.mcProfile?.name,
          minecraftUuid: mc?.mcProfile?.id,
          minecraftAccessToken: mc?.mcAccessToken
        };

        done();
        resolve(msAccount);
      });

      server.listen(19191);

      const authUrl = await pca.getAuthCodeUrl({
        scopes: MS_SCOPES,
        redirectUri: MS_REDIRECT_URI
      });

      popup = new BrowserWindow({
        width: 500,
        height: 650,
        title: "Microsoft Login",
        webPreferences: {
          nodeIntegration: false,
          contextIsolation: true
        }
      });

      popup.loadURL(authUrl);
    } catch (e) {
      reject(e);
    }
  });
}

// ============================================================
// IPC
// ============================================================
ipcMain.handle("ash:getSettings", () => settingsStore.loadSettings());
ipcMain.handle("ash:saveSettings", (_e, s) => (settingsStore.saveSettings(s), true));
ipcMain.handle("ash:getAccount", () => msAccount);

ipcMain.handle("ash:signInMicrosoft", async () => {
  try {
    if (msAccount) return { ok: true, account: msAccount };
    return { ok: true, account: await performInteractiveMicrosoftLogin() };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// ============================================================
// Launch Minecraft
// ============================================================
ipcMain.handle("ash:launchMinecraft", async (_event, options) => {
  const settings = settingsStore.loadSettings();

  // Try refreshing tokens silently
  try {
    const accounts = await pca.getTokenCache().getAllAccounts();
    if (accounts?.length) {
      const tokenResp = await pca.acquireTokenSilent({
        account: accounts[0],
        scopes: MS_SCOPES
      });

      const mc = await loginMinecraftWithMsAccessToken(tokenResp.accessToken);

      msAccount = {
        username: mc?.mcProfile?.name || accounts[0].username,
        minecraftName: mc?.mcProfile?.name,
        minecraftUuid: mc?.mcProfile?.id,
        minecraftAccessToken: mc?.mcAccessToken,
      };
    }
  } catch (e) {
    console.error("[Auth] Silent refresh failed:", e);
  }

  if (!msAccount?.minecraftAccessToken)
    throw new Error("Please log in with Microsoft first.");

  const javaPath = options.javaPath || settings.javaPath || "javaw.exe";
  const ramMB = options.ramMB || settings.ramMB || 4096;

  const mcDir = process.env.APPDATA
    ? path.join(process.env.APPDATA, ".minecraft")
    : path.join(os.homedir(), ".minecraft");

  // ensure version
  const { jarPath } = await ensureAshClientVersion(mcDir);

  // ensure libs + natives
  const librariesDir = path.join(mcDir, "libraries");
  await ensureLibraries(librariesDir);

  const nativesDir = path.join(mcDir, "natives", "ashclient-1.8.9");
  await extractNatives(librariesDir, nativesDir);

  // Ensure ClientInput.dll
  const clientInput = path.join(nativesDir, "ClientInput.dll");
  if (!(await fileExists(clientInput)))
    await downloadFile(CLIENTINPUT_URL, clientInput, "clientinput");

  // Ensure Discord RPC
  await fsp.mkdir(ASHCLIENT_STORAGE, { recursive: true });
  if (!(await fileExists(DISCORD_RPC_LOCAL_JAR)))
    await downloadFile(DISCORD_RPC_JAR_URL, DISCORD_RPC_LOCAL_JAR, "discord");

  const vanillaJar = path.join(mcDir, "versions", "1.8.9", "1.8.9.jar");
  const assetsDir = path.join(mcDir, "assets");

  const classpath =
    [
      jarPath,
      vanillaJar,
      DISCORD_RPC_LOCAL_JAR,
      ...LIBRARY_PATHS.map((r) => path.join(librariesDir, cleanRel(r)))
    ].join(path.delimiter);

  const jvmArgs = [
    `-Xmx${ramMB}m`,
    `-Djava.library.path=${nativesDir}`,
    `-Dorg.lwjgl.librarypath=${nativesDir}`,
    "-cp",
    classpath
  ];

  const mcArgs = [
    "net.minecraft.client.main.Main",
    "--version", "ashclient-1.8.9",
    "--gameDir", mcDir,
    "--assetsDir", assetsDir,
    "--assetIndex", "1.8",
    "--userType", "msa",
    "--versionType", "release",
    "--username", msAccount.username,
    "--uuid", msAccount.minecraftUuid,
    "--accessToken", msAccount.minecraftAccessToken
  ];

  const allArgs = [...jvmArgs, ...mcArgs];

  console.log("[Launcher] Launching:", javaPath, allArgs.join(" "));

  // tell UI → launching
  mainWindow.webContents.send("ash:playState", "launching");

  const child = spawn(javaPath, allArgs, {
    detached: false,
    stdio: ["ignore", "pipe", "pipe"]
  });

  let hasStarted = false;

  // GOOD BLOCK (kept)
  child.stdout.on("data", (d) => {
    if (!hasStarted) {
      hasStarted = true;
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("ash:playState", "running");
      }
    }
    console.log("[MC]", d.toString());
  });

  child.stderr.on("data", (d) => {
    console.error("[MC-ERR]", d.toString());
  });

  child.on("close", (code) => {
    console.log("[MC] exited with code", code);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send("ash:playState", "idle");
    }
  });

  return true;
});

// ============================================================
// App lifecycle
// ============================================================
app.whenReady().then(async () => {

  // Silent login
  await trySilentMicrosoftLoginAndMinecraft();

  // Create UI
  createMainWindow();

  // Updater
  const updated = await checkForLauncherUpdates(mainWindow);
  if (updated) {
    app.relaunch();
    app.exit();
    return;
  }

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

// ============================================================
// Updater Logic
// ============================================================
async function checkForLauncherUpdates(win) {
  const localVersion = require("./package.json").version;

  try {
    const remoteVersion = await fetchRemoteVersion();
    console.log("Local:", localVersion, "| Remote:", remoteVersion);

    if (remoteVersion !== localVersion) {
      console.log("[Updater] Update available:", remoteVersion);

      if (win && !win.isDestroyed()) {
        win.webContents.send("ash:launchUpdate", {
          localVersion,
          remoteVersion
        });
      }

      await downloadAndApplyUpdate();
      return true;
    }
  } catch (e) {
    console.error("[Updater] Failed:", e);
  }

  return false;
}
